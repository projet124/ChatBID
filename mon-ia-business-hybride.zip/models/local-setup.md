# Setup des modèles locaux
Instructions pour Ollama, Stable Diffusion, etc.
