# FastAPI server setup
